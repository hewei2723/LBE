-- H2 2.3.232;
;             
CREATE USER IF NOT EXISTS "" SALT '' HASH '' ADMIN;           
