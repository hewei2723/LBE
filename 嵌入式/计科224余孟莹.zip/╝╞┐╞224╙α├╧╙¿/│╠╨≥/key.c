void key(void)
{
   	
	if (P2==0xcf)
	{
	cp2++;
	if(cp2%2==0)
	cp2=0;
	if(cp2%2==1)
	cp2=1;
	}
	while(P2==0xcf);
	P2 = 0xef;
	if(P2 == 0xee)
	{
	 	cp2++;
		if(cp2 >= 7)cp2 = 2;	
	}
	while(P2 == 0xee);

	if(P2 == 0xed)
	{
	 	if(cp2 == 2){hour++;if(hour >= 24)hour = 23;}
	 	if(cp2 == 3){min++;if(min >= 60)min = 59;}		
	 	if(cp2 == 4){sec++;if(sec >= 60)sec = 59;}		
	 	if(cp2 == 5){hour_n++;if(hour_n >= 24)hour_n = 23;}		
	 	if(cp2 == 6){min_n++;if(min_n >= 60)min_n = 59;}			
	}
	while(P2 == 0xed);

	if(P2 == 0xeb)
	{
	 	if(cp2 == 2){hour--;if(hour >= 24)hour = 23;}
	 	if(cp2 == 3){min--;if(min >= 60)min = 59;}		
	 	if(cp2 == 4){sec--;if(sec >= 60)sec = 59;}		
	 	if(cp2 == 5){hour_n++;if(hour_n >= 24)hour_n = 23;}		
	 	if(cp2 == 6){min_n++;if(min_n >= 60)min_n = 59;}	 		
	}
	while(P2 == 0xeb);

	if(P2 == 0xe7)
	{
	 	cp2 = 1;	
	}
	while(P2 == 0xe7);

}