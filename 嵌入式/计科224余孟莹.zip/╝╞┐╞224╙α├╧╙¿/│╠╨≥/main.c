#include<reg51.h>
#include<display.c>
#include<key.c>
void t0_isr(void) interrupt 1
{
	TH0 = (65536 - 2000) / 256;
	TL0 = (65536 - 2000) % 256;
	cp++;
	if(cp >= 500){cp = 0;sec++;cp3++;flash = ~flash;}
	if(sec >= 60){sec = 0;min++;}
	if(min >= 60){min = 0;hour++;}
	if(hour >= 24)hour = 0;
	P0 = 0xff;P0 = bit_scan[cp1];le = 1;le = 0;P0 = display_num[cp1];
	cp1++;if(cp1 >= 8)cp1 = 0;
}
void t0_init(void)
{
	TMOD = 0x01;
	TH0 = (65536 - 2000) / 256;
	TL0 = (65536 - 2000) % 256;
	EA = 1;
	ET0 = 1;
	TR0 = 1;
}
void main(void)
{
	t0_init();
	cp2 = 0;
	display();
	while(cp3 <= 2);
	cp2 = 1;
	cp3 = 0;
	while(1)
	{
	 	display();
		key();
		if(hour == hour_n && min == min_n)led = 0;
		else led = 1;		
	}
}