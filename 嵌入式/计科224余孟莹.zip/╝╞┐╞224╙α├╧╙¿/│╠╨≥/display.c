unsigned char sec,min,hour,cp1,cp2,cp3,flash,hour_n,min_n;
unsigned char bit_scan[] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
unsigned char seven_seg[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
unsigned char display_num[8];
unsigned int cp;
sbit le = P1^0;
sbit led = P1^7;
void display(void)
{
	if(cp2 == 0)
	{
		display_num[0] = seven_seg[1];
		display_num[1] = seven_seg[8];
		display_num[2] = seven_seg[4];
		display_num[3] = seven_seg[3];
		display_num[4] = seven_seg[7];
		display_num[5] = seven_seg[6];
		display_num[6] = seven_seg[6];
		display_num[7] = seven_seg[8];
	}
	if(cp2 == 1)
	{
		display_num[0] = seven_seg[hour / 10];
		display_num[1] = seven_seg[hour % 10];
		display_num[2] = 0xbf | flash;
		display_num[3] = seven_seg[min / 10];
		display_num[4] = seven_seg[min % 10];
		display_num[5] = 0xbf | flash;
		display_num[6] = seven_seg[sec / 10];
		display_num[7] = seven_seg[sec % 10];
	}
	if(cp2 == 2)
	{
		display_num[0] = seven_seg[hour / 10] | flash;
		display_num[1] = seven_seg[hour % 10] | flash;
		display_num[2] = 0xbf;
		display_num[3] = seven_seg[min / 10];
		display_num[4] = seven_seg[min % 10];
		display_num[5] = 0xbf;
		display_num[6] = seven_seg[sec / 10];
		display_num[7] = seven_seg[sec % 10];
	}
	if(cp2 == 3)
	{
		display_num[0] = seven_seg[hour / 10];
		display_num[1] = seven_seg[hour % 10];
		display_num[2] = 0xbf;
		display_num[3] = seven_seg[min / 10] | flash;
		display_num[4] = seven_seg[min % 10] | flash;
		display_num[5] = 0xbf;
		display_num[6] = seven_seg[sec / 10];
		display_num[7] = seven_seg[sec % 10];
	}
	if(cp2 == 4)
	{
		display_num[0] = seven_seg[hour / 10];
		display_num[1] = seven_seg[hour % 10];
		display_num[2] = 0xbf;
		display_num[3] = seven_seg[min / 10];
		display_num[4] = seven_seg[min % 10];
		display_num[5] = 0xbf;
		display_num[6] = seven_seg[sec / 10] | flash;
		display_num[7] = seven_seg[sec % 10] | flash;
	}
	if(cp2 == 5)
	{
		display_num[0] = seven_seg[min_n / 10];
		display_num[1] = seven_seg[min_n % 10];
		display_num[2] = 0xbf;
		display_num[3] = seven_seg[hour_n / 10] | flash;
		display_num[4] = seven_seg[hour_n % 10] | flash;
		display_num[5] = 0xbf;
		display_num[6] = 0xff;
		display_num[7] = 0xff;
	}
	if(cp2 == 6)
	{
		display_num[0] = seven_seg[min_n / 10] | flash;
		display_num[1] = seven_seg[min_n % 10] | flash;
		display_num[2] = 0xbf;
		display_num[3] = seven_seg[hour_n / 10];
		display_num[4] = seven_seg[hour_n % 10];
		display_num[5] = 0xbf;
		display_num[6] = 0xff;
		display_num[7] = 0xff;
	}

}