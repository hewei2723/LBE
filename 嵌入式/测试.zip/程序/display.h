//dispaly.c
#include <intrins.h>					  //�⺯����ͷ�ļ�
#define uchar unsigned char								//�� unsigned char �궨��Ϊ uchar
#define uint unsigned int	
#define nop _nop_()
sbit sda = P1^4;						  //��sda��P3.6�˿�
sbit scl = P1^3;						  //��scl��P3.7�˿�
sbit DQ = P1^2;													//���嵥Ƭ����P2.7��DS18B20���ݶ˿�������һ��  
							//�� unsigned int �궨��Ϊ uint
uchar sec,min = 17,hour = 20,year = 24,month = 12,date = 6,week;
sbit rst1 = P3^4;										//���帴λ/Ƭѡ�߽�P3.4
sbit scl1 = P3^7;										//���崮��ʱ�����Ž�P3.7
sbit sda1 = P3^5;

unsigned char flash,cp1,cp2,cp3,cp4,cp5,hour_n,min_n;
unsigned char num1,num2,num3,num4,num5,num6;
unsigned char seven_seg[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
unsigned char b_s[] = {0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};
unsigned char seg_num[8];
unsigned int temp,temp_dot;
unsigned int cp;
sbit LE = P1^0;

#include<at24c04.h>
#include<ds18b20.h>
#include<ds1302.h>
#include<key.h>

void display(void)
{
    if(cp2 == 0) // ��ʾѧ��
    {
        seg_num[7] = seven_seg[num1 / 10];
        seg_num[6] = seven_seg[num1 % 10];
        seg_num[5] = seven_seg[num2 / 10];
        seg_num[4] = seven_seg[num2 % 10];
        seg_num[3] = seven_seg[num3 / 10];
        seg_num[2] = seven_seg[num3 % 10];
        seg_num[1] = seven_seg[num4 % 10];
        seg_num[0] = seven_seg[num4 /10];
    }
    if(cp2 == 1) // ��ʾ�绰�������λ,�¶�
    {
        seg_num[7] = seven_seg[num5 ];
        seg_num[6] = seven_seg[num6 / 10];
        seg_num[5] = seven_seg[num6 % 10];
        seg_num[4] = 0xff;
        seg_num[3] = 0xff;
        seg_num[2] = seven_seg[temp / 10];
        seg_num[1] = seven_seg[temp % 10] & 0x7f;
        seg_num[0] = seven_seg[temp_dot];
    }
  if(cp2 == 2) // ��ʾ������
    {
		seg_num[0] = seven_seg[date % 10];
		seg_num[1] = seven_seg[date / 10];	
		seg_num[2] = seven_seg[month % 10];
		seg_num[3] = seven_seg[month / 10];		
		seg_num[4] = seven_seg[year % 10];
		seg_num[5] = seven_seg[year / 10];	
		seg_num[6] = seven_seg[0];
		seg_num[7] = seven_seg[2];
    }
    if(cp2 == 3 && cp3 == 0)//������ʱ
	{
		seg_num[0] = seven_seg[sec % 10];
		seg_num[1] = seven_seg[sec / 10];	
		seg_num[2] = 0xbf | flash;
		seg_num[3] = seven_seg[min % 10];		
		seg_num[4] = seven_seg[min / 10];
		seg_num[5] = 0xbf | flash;	
		seg_num[6] = seven_seg[hour % 10];
		seg_num[7] = seven_seg[hour / 10];
	}
	//����ʱ������״̬			
	if(cp3 == 1) 
	{
		seg_num[0] = seven_seg[sec % 10];
		seg_num[1] = seven_seg[sec / 10];	
		seg_num[2] = 0xbf;
		seg_num[3] = seven_seg[min % 10];		
		seg_num[4] = seven_seg[min / 10];
		seg_num[5] = 0xbf;	
		seg_num[6] = seven_seg[hour % 10] | flash;
		seg_num[7] = seven_seg[hour / 10] | flash;
	}
	if(cp3 == 2) 
	{
		seg_num[0] = seven_seg[sec % 10];
		seg_num[1] = seven_seg[sec / 10];	
		seg_num[2] = 0xbf;
		seg_num[3] = seven_seg[min % 10] | flash;		
		seg_num[4] = seven_seg[min / 10] | flash;
		seg_num[5] = 0xbf;	
		seg_num[6] = seven_seg[hour % 10];
		seg_num[7] = seven_seg[hour / 10];
	}	
	if(cp3 == 3) 
	{
		seg_num[0] = seven_seg[sec % 10] | flash;
		seg_num[1] = seven_seg[sec / 10] | flash;	
		seg_num[2] = 0xbf;
		seg_num[3] = seven_seg[min % 10];		
		seg_num[4] = seven_seg[min / 10];
		seg_num[5] = 0xbf;	
		seg_num[6] = seven_seg[hour % 10];
		seg_num[7] = seven_seg[hour / 10];
	}					
	if(cp3 == 4)
	{
		seg_num[0] = 0xff;
		seg_num[1] = 0xff;
		seg_num[2] = 0xff;
		seg_num[3] = seven_seg[min_n % 10];
		seg_num[4] = seven_seg[min_n / 10];	
		seg_num[5] = 0xbf;	
		seg_num[6] = seven_seg[hour_n % 10] | flash;		
		seg_num[7] = seven_seg[hour_n / 10] | flash;
	}				
	if(cp3 == 5)
	{
		seg_num[0] = 0xff;
		seg_num[1] = 0xff;
		seg_num[2] = 0xff;
		seg_num[3] = seven_seg[min_n % 10] | flash;
		seg_num[4] = seven_seg[min_n / 10] | flash;	
		seg_num[5] = 0xbf;	
		seg_num[6] = seven_seg[hour_n % 10];		
		seg_num[7] = seven_seg[hour_n / 10];
	}		
}
