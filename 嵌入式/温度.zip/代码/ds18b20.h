unsigned int temp_dat;  
sbit dq = P1^2;

void delay(unsigned int x) { 
    while (x--); 
}

void ds18b20_init(void) {
    dq = 1; 
    dq = 0; 
    delay(80);  
    dq = 1;  
    delay(20);
}

void write_ds18b20(unsigned char x) {
    unsigned char i;
    for (i = 0; i < 8; i++) {
        dq = 0;
        dq = (x & 0x01);
        delay(5);
        dq = 1;
        x >>= 1;
    }
}

unsigned char read_ds18b20(void) {
    unsigned char i, j = 0;
    for (i = 0; i < 8; i++) {
        dq = 0;
        dq = 1;  
        j >>= 1;
        if (dq) j |= 0x80;
        delay(5);
    }
    return j;
}

void read_temp_ds18b20(void) {
    unsigned char lsb, msb;

    ds18b20_init();         
    write_ds18b20(0xcc);    
    write_ds18b20(0x44);    

    delay(750);             

    ds18b20_init();         
    write_ds18b20(0xcc);    
    write_ds18b20(0xbe);    

    lsb = read_ds18b20();   
    msb = read_ds18b20();   

    temp_dat = (msb << 8) | lsb;  
}
